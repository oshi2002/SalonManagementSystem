/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;


import javax.swing.JOptionPane;
import java.sql.*;
import java.awt.HeadlessException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author USER
 */
public class JDBC {
    public static void main(String[] args) {
        connectdb();
    }
    public static Connection connectdb(){
        try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/kaveesalonsystem","root","2002");
        System.out.println("successful");
        return conn;
        } catch (HeadlessException | ClassNotFoundException | java.sql.SQLException e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
}
